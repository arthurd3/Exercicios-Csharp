﻿using System;

class Program
{
    public static void Main(string[] args)
    {
        SequenciaFibonacci(100);
    }

    public static void SequenciaFibonacci(int numeros, int i = 0, int prev = 0, int curr = 1)
    {
        if (i < numeros)
        {
            Console.Write("{0} ", curr);
            SequenciaFibonacci(numeros, ++i, curr, prev + curr);
        }
    }
}
