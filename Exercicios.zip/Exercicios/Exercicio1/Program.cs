﻿class Program
{
    public static void Main(string[] args)
    {
        intervaloRec(14);
    }
    public static void intervaloRec(int num)
    {
        if (num > 0)
        {
            if (num % 2 == 0 && num % 3 == 0)
            {
                Console.Write(" " + num);
                intervaloRec(num - 1);

            }
            else intervaloRec(num - 1);
        }
    }
}