﻿class Program
{
    public static void Main(string[] args)
    {
        int[] vet = new int[6] { 1, -2, 3, -4, -5, 6 };
        int i = vet.Length - 1, negativos = 0;

        int cont = tranformarPositivo(vet, i, negativos);
        Console.Write(cont);
    }

    public static int tranformarPositivo(int[] vet, int i, int negativos)
    {
        if (i >= 0)
        {
            if (vet[i] < 0)
            {
                vet[i] *= -1;
                negativos++;
            }
            return tranformarPositivo(vet, i - 1, negativos);
        }
        return negativos;
    }
}
