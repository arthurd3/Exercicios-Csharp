﻿class Program
{
    public static void Main(string[] args)
    {

        Console.Write(funcaoFatorial(5));


    }
    public static int funcaoFatorial(int n)
    {
        if (n == 0)
            return 1;
        else
            return n * funcaoFatorial(n - 1);





    }

}