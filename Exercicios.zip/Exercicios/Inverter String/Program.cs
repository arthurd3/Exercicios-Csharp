﻿class Program
{


    public static void Main(string[] args)
    {
        string palavra = "Thuzin";
        int i = palavra.Length -1;
        inverterString(palavra);



    }
    public static string inverterString(string palavra , int i  )
    {
        if(i > 0)
        {
            char aux = palavra[i];
            palavra[i] =palavra[i-1];
            palavra[i-1] = aux;

        }




    }


}