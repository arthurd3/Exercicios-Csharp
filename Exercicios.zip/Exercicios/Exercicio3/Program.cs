﻿class Program
{

    public static void Main(string[] args)
    {
        int[] vet = new int[7] { 6, 7, 9, 5, 30, 11, 20 };
        int cont = ordernarBolha(vet);
        cont++;
        Console.Write("Numero De Vezes Alteradas : " + cont);

    }
    public static int ordernarBolha(int[] vet, int cont = 0)
    {
        int aux;
        for (int i = 0; i < vet.Length; i++)
        {
            for (int j = 0; j < vet.Length - 1 - i; j++)
            {
                if (vet[j] > vet[j + 1])
                {
                    aux = vet[j];
                    vet[j] = vet[j + 1];
                    vet[j + 1] = aux;
                    cont++;
                }
            }

        }
        for (int k = 0; k < vet.Length; k++)
        {
            Console.Write(" " + vet[k]);
        }
        Console.Write("\n");
        return cont;






    }





}